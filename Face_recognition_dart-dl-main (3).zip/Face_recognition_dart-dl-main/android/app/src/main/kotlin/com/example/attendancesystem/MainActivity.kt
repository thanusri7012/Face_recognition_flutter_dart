package com.example.attendancesystem

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
